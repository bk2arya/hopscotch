    var tour = {
      id: "hello-hopscotch",
	   onStart: function() {
          document.getElementById('header').style.zIndex = "3";
		  document.getElementById('header').style.background = 'white';
		  document.getElementById('header').style.pointerEvents = "none";
		  document.getElementById('header').style.position = "relative";
      },
	   onEnd: function() {
          document.getElementById('header').style.zIndex = 'unset';
      document.getElementById('header').style.background = 'none';
      document.getElementById('header').style.pointerEvents = "auto";
      document.getElementById('header').style.position = "none";
	  
	  document.getElementById('content1').style.zIndex = 'unset';
      document.getElementById('content1').style.background = 'none';
      document.getElementById('content1').style.pointerEvents = "auto";
      document.getElementById('content1').style.position = "none";
	  
	  document.getElementById('content2').style.zIndex = 'unset';
      document.getElementById('content2').style.background = 'none';
      document.getElementById('content2').style.pointerEvents = "auto";
      document.getElementById('content2').style.position = "none";
	  
	  document.getElementById('content3').style.zIndex = 'unset';
      document.getElementById('content3').style.background = 'none';
      document.getElementById('content3').style.pointerEvents = "auto";
      document.getElementById('content3').style.position = "none";
	  
	  document.getElementById('button').style.zIndex = 'unset';
      document.getElementById('button').style.background = 'none';
      document.getElementById('button').style.pointerEvents = "auto";
      document.getElementById('button').style.position = "none";
	  
	  document.body.style.overflow='scroll';
	document.getElementById('overlay').style.display= 'none';
	//document.getElementById('overlay').style.overflow= '';
      },
	   onClose: function() {
          document.getElementById('header').style.zIndex = 'unset';
      document.getElementById('header').style.background = 'none';
      document.getElementById('header').style.pointerEvents = "auto";
      document.getElementById('header').style.position = "none";
	  
	  document.getElementById('content1').style.zIndex = 'unset';
      document.getElementById('content1').style.background = 'none';
      document.getElementById('content1').style.pointerEvents = "auto";
      document.getElementById('content1').style.position = "none";
	  
	  document.getElementById('content2').style.zIndex = 'unset';
      document.getElementById('content2').style.background = 'none';
      document.getElementById('content2').style.pointerEvents = "auto";
      document.getElementById('content2').style.position = "none";
	  
	  document.getElementById('content3').style.zIndex = 'unset';
      document.getElementById('content3').style.background = 'none';
      document.getElementById('content3').style.pointerEvents = "auto";
      document.getElementById('content3').style.position = "none";
	  
	  document.getElementById('button').style.zIndex = 'unset';
      document.getElementById('button').style.background = 'none';
      document.getElementById('button').style.pointerEvents = "auto";
      document.getElementById('button').style.position = "none";
	  
	  document.body.style.overflow='scroll';
	document.getElementById('overlay').style.display= 'none';
	//document.getElementById('overlay').style.overflow= '';
      },
      steps: [
        {
          title: "My Header",
          content: "This is the header of my page.",
          target: "header",
          placement: "bottom",
		  onNext: function() {

      document.getElementById('header').style.zIndex = 'unset';
      document.getElementById('header').style.background = 'none';
      document.getElementById('header').style.pointerEvents = "auto";
      document.getElementById('header').style.position = "none";

      document.getElementById('content1').style.zIndex = '3';
      document.getElementById('content1').style.background = 'white';
      document.getElementById('content1').style.pointerEvents = "none";
      document.getElementById('content1').style.position = "relative";

      }
        },
        {
          title: "Content 1",
          content: "Heyy..!!",
          target: "content1",
          placement: "left",
		  "showPrevButton": true,
		  onPrev:  function() {

      document.getElementById('content1').style.zIndex = 'unset';
      document.getElementById('content1').style.background = 'none';
      document.getElementById('content1').style.pointerEvents = "auto";
      document.getElementById('content1').style.position = "none";

      document.getElementById('header').style.zIndex = '3';
      document.getElementById('header').style.background = 'white';
      document.getElementById('header').style.pointerEvents = "none";
      document.getElementById('header').style.position = "relative";

      },
        onNext: function() {

      document.getElementById('content1').style.zIndex = 'unset';
      document.getElementById('content1').style.background = 'none';
      document.getElementById('content1').style.pointerEvents = "auto";
      document.getElementById('content1').style.position = "none";

      document.getElementById('content2').style.zIndex = '3';
      document.getElementById('content2').style.background = 'white';
      document.getElementById('content2').style.pointerEvents = "none";
      document.getElementById('content2').style.position = "relative";

      }
        },
        {
          title: "Content 2",
          content: "I am doing good, hope you are doing well..!!",
          target: "content2",
          placement: "top",
		  "showPrevButton": true,
		    onPrev:  function() {

      document.getElementById('content2').style.zIndex = 'unset';
      document.getElementById('content2').style.background = 'none';
      document.getElementById('content2').style.pointerEvents = "auto";
      document.getElementById('content2').style.position = "none";

      document.getElementById('content1').style.zIndex = '3';
      document.getElementById('content1').style.background = 'white';
      document.getElementById('content1').style.pointerEvents = "none";
      document.getElementById('content1').style.position = "relative";

      },
        onNext: function() {

      document.getElementById('content2').style.zIndex = 'unset';
      document.getElementById('content2').style.background = 'none';
      document.getElementById('content2').style.pointerEvents = "auto";
      document.getElementById('content2').style.position = "none";

      document.getElementById('content3').style.zIndex = '3';
      document.getElementById('content3').style.background = 'white';
      document.getElementById('content3').style.pointerEvents = "none";
      document.getElementById('content3').style.position = "relative";

      }
        },
        {
          title: "Content 3",
          content: "Yes, it freaking is. :(",
          target: "content3",
          placement: "bottom",
		  "showPrevButton": true,
		      onPrev:  function() {

      document.getElementById('content3').style.zIndex = 'unset';
      document.getElementById('content3').style.background = 'none';
      document.getElementById('content3').style.pointerEvents = "auto";
      document.getElementById('content3').style.position = "none";

      document.getElementById('content2').style.zIndex = '3';
      document.getElementById('content2').style.background = 'white';
      document.getElementById('content2').style.pointerEvents = "none";
      document.getElementById('content2').style.position = "relative";

      },
        onNext: function() {

      document.getElementById('content3').style.zIndex = 'unset';
      document.getElementById('content3').style.background = 'none';
      document.getElementById('content3').style.pointerEvents = "auto";
      document.getElementById('content3').style.position = "none";

      document.getElementById('button').style.zIndex = '3';
      document.getElementById('button').style.background = 'white';
      document.getElementById('button').style.pointerEvents = "none";
      document.getElementById('button').style.position = "relative";

      }
        }
		,
        {
          title: "Click to repeat tour",
          content: "Here is where I put my content.",
          target: "button",
          placement: "right",
		  "showPrevButton": true,
		         onPrev:  function() {

      document.getElementById('button').style.zIndex = 'unset';
      document.getElementById('button').style.background = 'none';
      document.getElementById('button').style.pointerEvents = "auto";
      document.getElementById('button').style.position = "none";

      document.getElementById('content3').style.zIndex = '3';
      document.getElementById('content3').style.background = 'white';
      document.getElementById('content3').style.pointerEvents = "none";
      document.getElementById('content3').style.position = "relative";

      },
        }
      ]
    };

    // Start the tour!
	function startTour() {
	document.body.style.overflow='hidden';
    //var elem = document.getElementById('overlay1').['style'];
    //elem.display = 'block';
    //elem.overflow = 'scroll';
	document.getElementById('overlay').style.display= 'block';
	document.getElementById('overlay').style.overflow= 'scroll';
	hopscotch.startTour(tour);
}

	function ahs() {
		alert("Clicked..!!");
	}
    