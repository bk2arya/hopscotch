var tourObj = {
  id: "hello-hopscotch",
  onStart: ["na"],
  onEnd: ["na"],
  onClose: ['closeTour'],

  steps: [
    {
          id: 0,
          title: "My Header",
          content: "This is the header of my page.",
          target: "header",
          placement: "bottom",
          showPrevButton: false,
          zindex: 3,
          onNext: ["na"]
    },
    {
          id: 1,
          title: "Content 1",
          content: "Heyy..!!",
          target: "content1",
          placement: "left",
          showPrevButton: true,
          zindex: 3,
          onPrev: ["na"],
          onNext: ["na"],
    },
    {
      id: 2,
      title: "Content 2",
      content: "I am doing good, hope you are doing well..!!",
      target: "content2",
      placement: "top",
      showPrevButton: true,
      zindex: 3,
      onPrev: ["na"],
      onNext: ["na"],
    },
    {
      id: 3,
      title: "Content 3",
      content: "Yes, it freaking is. :(",
      target: "content3",
      placement: "bottom",
		  showPrevButton: true,
      zindex: 3,
      onPrev: ["na"],
      onNext: ["na"],
    },
    {
      id: 4,
      title: "Click to repeat tour",
      content: "Here is where I put my content.",
      target: "button",
      placement: "right",
		  showPrevButton: true,
      zindex: 3,
      onPrev: ["na"],
    }
  ]
};

function startTour(){
  enable();

    var steps = tourObj.steps;
    var noOfSteps = tourObj.steps.length;
    var idx = 0;

    steps.forEach((step, index) => {
      if(index == 0){
        var helperName = 'helper'+idx;
        var currId = step.target;
        registerOnStartHelper(helperName, currId);
        //set the onstart variable with 'helper'+idx
        tourObj.onStart[0] = helperName;

        idx=idx+1;
        helperName = 'helper'+idx;
        registerOnNextHelper(helperName,step.target,steps[1].target);
        //set the onNext variable with 'helper'+idx
        helperName='helper'+idx;
        step.onNext[0] = helperName;
        //alert(this.tourObj.steps[0].onNext[0]);

      }
      else if(index == noOfSteps-1){

        
        idx=idx+1;
        var prvIdx = step.id-1;
        var helperName = 'helper'+idx;
        registerOnPrevHelper(helperName,step.target,steps[prvIdx].target);
        step.onPrev[0] = helperName;

        idx=idx+1;
        helperName = 'helper'+idx;
        registerOnEndHelper(helperName,step.target);
        tourObj.onEnd[0] = helperName;

      }
      else{

        idx=idx+1;
        var nxtIdx = step.id+1;
        var helperName = 'helper'+idx;
        registerOnNextHelper(helperName,step.target,steps[nxtIdx].target);
        step.onNext[0] = helperName;

        idx=idx+1;
        var prvIdx = step.id-1;
        helperName = 'helper'+idx;
        registerOnPrevHelper(helperName,step.target,steps[prvIdx].target);
        step.onPrev[0] = helperName;


      }
      registerOnCloseHelper("closeTour", tourObj);
      
    });

  hopscotch.startTour(tourObj);
}

function enable(){
  document.body.style.overflow='hidden';
  document.getElementById('overlay').style.display= 'block';
  document.getElementById('overlay').style.overflow= 'scroll';
}

function registerOnStartHelper(helperName, currId){

  hopscotch.registerHelper(helperName, function() {
    //this.divHighlight(currId);
    document.getElementById(currId).style.zIndex = "3";
    document.getElementById(currId).style.background = 'white';
    document.getElementById(currId).style.pointerEvents = "none";
    }
  );
    
}

function registerOnEndHelper(helperName, currId){

  hopscotch.registerHelper(helperName, //this.onEnd(currId)
    function() {
    // this.onEnd(currId);
    document.getElementById(currId).style.zIndex = 'unset';
    document.getElementById(currId).style.background = 'none';
    document.getElementById(currId).style.pointerEvents = "auto";
    document.getElementById(currId).style.position = "none";

    document.getElementById("overlay").style.display = "none";
    document.body.style.overflow='scroll';

    }
  );
    
}

function registerOnCloseHelper(helperName, tourObj){


  hopscotch.registerHelper(helperName, function() {

    var stepArr = tourObj.steps;

  stepArr.forEach(step => {
    document.getElementById(step.target).style.zIndex = 'unset';
    document.getElementById(step.target).style.background = 'none';
    document.getElementById(step.target).style.pointerEvents = "auto";
    document.getElementById(step.target).style.position = "none";
  });

    document.getElementById("overlay").style.display = "none";
    document.body.style.overflow='scroll';

    });
    
}

function registerOnNextHelper(helperName, currId, nextId){

  hopscotch.registerHelper(helperName, //this.onNext(currId,nextId)
    function() {

    document.getElementById(currId).style.zIndex = 'unset';
    document.getElementById(currId).style.background = 'none';
    document.getElementById(currId).style.pointerEvents = "auto";
    document.getElementById(currId).style.position = "none";

    document.getElementById(nextId).style.zIndex = '3';
    document.getElementById(nextId).style.background = 'white';
    document.getElementById(nextId).style.pointerEvents = "none";
    document.getElementById(nextId).style.position = "relative";

    }
  );
    
}

function registerOnPrevHelper(helperName, currId, prevId){

  hopscotch.registerHelper(helperName, //this.onPrev(currId,prevId): didnt work
    function() {
    // this.divRemoveHighlight(currId); didnt work
    // this.divHighlight(prevId); didnt work

    document.getElementById(currId).style.zIndex = 'unset';
    document.getElementById(currId).style.background = 'none';
    document.getElementById(currId).style.pointerEvents = "auto";
    document.getElementById(currId).style.position = "none";

    document.getElementById(prevId).style.zIndex = '3';
  document.getElementById(prevId).style.background = 'white';
  document.getElementById(prevId).style.pointerEvents = "none";
  document.getElementById(prevId).style.position = "relative";
    }
  );
    
}

	function ahs() {
		alert("Clicked..!!");
	}