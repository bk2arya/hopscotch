Folder structure understanding.

1. the folders 
	a. css
		-- hopscotch.css (provided by hopscotch)
		-- overlay.css*   (custom overlay screen added by me, the effect which blackens out the background)
	b. img
		-- all images inside here are provided by hopscotch
	c. js
		-- hopscotch.js 		(procided by hopscotch)
		-- my_first_tour.js* 		(the actual code of tour is here, this includes manual dom manipulations)
		-- my_first_tour_dynamic.js* 	(the actual code of tour is here and automates the dom manipulation)

2. home.html		-- bound with my_first_tour.js
   home_dynamic.html	-- bound with my_first_tour_dynamic.js

NOTE
1. Folders included for this demo is bare minimum to make use of hopscotch.
2. * - files created by me.
3. Hopscotch is also available as an npm package.
4. For indepth explaination please visit website: https://linkedin.github.io/hopscotch/